//Write a program that asks the user for two inputs: 
//lower limit and upper limit. Now write a function named 
//display that prints all the numbers between those limits.
//NOTE: You are only allowed to pass one parameter to the 
//function and lower limit and upper limit variables should 
//not be made global.in

# include<stdio.h>

struct value{
		
	int lowerLimit;
	int upperLimit ;
};

void display(struct value accessedValue){
	
	int a = accessedValue.lowerLimit;
	int b = accessedValue.upperLimit;
	
	
	
	for (int i =a; i<=b; i++){
		
		printf("%d\n",i+1);
	}
}


int main(){
	struct value calcValue;
	
	printf("Enter lower limit value");
	scanf("%d",&calcValue.lowerLimit);

	printf("Enter upper limit value");
	scanf("%d",&calcValue.upperLimit);	
	
	display(calcValue);
	
	return 0;
	
}

