//Create a structure named student that has a name, roll 
//number and marks as members. Assume appropriate types 
//and size of members. Use this structure to read and 
//display records of 10 students. Create two functions: 
//One is to read information of students and other to
// display the information.


#include <stdio.h>

struct student {
    char name[50];
    int rollNo;
    float marks;
} stud[10];

void readData() {
	
	for(int i=0; i<10; i++){
	
	printf("Enter the name of students: ");
    scanf("%s", stud[i].name);

    printf("Enter the roll no: ");
    scanf("%d", &stud[i].rollNo);

    printf("Enter the marks: ");
    scanf("%f", &stud[i].marks);
		
	}

}

int main() {
    readData();
    for (int i = 0; i < 10; i++) {
        printf("Details of student %d:\n", i + 1);
        printf("Name: %s\n", stud[i].name);
        printf("Rollno: %d\n", stud[i].rollNo);
        printf("Marks: %.2f\n", stud[i].marks);
    }

    return 0;
}
