# include <stdio.h>
# include <math.h>

void pythagoras (float p, float b, float h){
	
	if (isnan(p)){
		
		printf("\n Perpendicular (p) = %f", sqrt(h*h - b*b));
		
	} else if (isnan (b)){
		
		printf("\n Base (b) = %f", sqrt(h*h -p*p));
	} else{
		
		printf("\n Hypotenuse (h) = %f", sqrt(b*b + p*p));
	}
}

int main(){
	
	pythagoras( 1,2,NAN);
	pythagoras( 3,NAN,5);
	pythagoras( NAN,2,3);
	return 0;
}

