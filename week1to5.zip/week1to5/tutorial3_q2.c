// WAP to find the largest element of an array. 

# include <stdio.h>

int main(){
	
	int max =0;
	int Array1[5] = {1,2,3,4,5};
	for (int i=0; i<5; i++){
		int num = i;
		if (Array1[i]>num){
			
			 max = Array1[i];
	
		}

	}
	printf("\nThis is largest element in the array %d",max);
		
	return 0;
} 

