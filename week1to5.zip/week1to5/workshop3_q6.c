// Write a program in C to take three numbers from the user and print the sum,
// multiplication, quotient, subtraction and minimum between three numbers
// using a pointer.

# include <stdio.h>

void calculation (int *a, int *b, int *c ){
	
	int sum = *a + *b + *c;
	printf("Sum of three numbers %d\n", sum);
	
	int difference = *a-*b-*c;
	printf("Difference of three numbers %d\n", difference);
	
	int multiply = *a * *b * *c;
	printf("Product of three numbers %d\n", multiply);
	
	int remainder = *a % *b % *c;
	printf("Remainder of three numbers %d\n", remainder);
	 
	if (*a>*b && *a>*c){
		
		printf("%d is greatest of all ",*a);
		
	} else if (*b>*a && *b>*c){
		
		printf("%d is greatest of all",*b);
		
	} else if (*c>*b && *c>*a){
		
		printf("%d is greatest of all",*c);
	}
	
}

int main (){
	
	int a,b,c;
	printf("Enter three numbers");
	scanf("%d %d %d", &a,&b,&c);
	
	calculation(&a,&b,&c);
}


