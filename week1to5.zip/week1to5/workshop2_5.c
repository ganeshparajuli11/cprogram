// Write a void function named “equations” which solves simultaneous equations. Your
// program will take six parameters. E.g. function(double a, double b, double c, double d,
// double e, double f){}. By solving simultaneous equations, you are finding where the two
// lines cross each other, so your function should print an x and y coordinate.
// ax+by=c …...(i)
// dx+ey=f........(ii)
// a = number in front of x of equation one
// b = number in front of y of equation one
// c = constant of equation one
// d = number in front of x of equation two
// e = number in front of y of equation two
// f = constant of equation two

# include <stdio.h>


void equations (float a, float b, float c, float d, float e, float f){
	
	// using cramers rule to solve the euqation 
	
	float x = ((c*e) - (b*f))/ ((a*e)-(b*d));
	float y = ((a*f) - (c*d))/ ((a*e)-(b*d));
	
	printf("Value of x is %.2f",x);
	printf("\nValue of y is %.2f",y);
}

int main (){
	
	float a,b,c,d,e,f;
	
	printf ("Enter value for a,b,c,d,e,f");
	scanf("%f %f %f %f %f %f",&a,&b,&c,&d,&e,&f);
	
	equations(a,b,c,d,e,f);
	
	return 0;
}