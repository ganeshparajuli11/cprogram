// Write a program in C to take two numbers from the user and print the
//maximum between two numbers using a pointer.

# include <stdio.h>

int main (){
	
	int a, b;
	int *c, *d;
	printf("Enter two number");
	scanf("%d %d", &a,&b);
	
	c = &a;
	d = &b;
	
	if (*c>*d){
		
		printf("%d is greater than %d",*c,*d);
	} else if (*c<*d){
		
		printf("%d is greater than %d",*d,*c);
	}
	
	return 0;
}
