// Write a program to count and find the sum of all the 
// numbers in the array, which are exactly divisible by 5
// and not divisible by 2 and 3. Assign an array to a 
// pointer. Print out address of pointer, array and 
// first element of an array using “%p” formatter.

