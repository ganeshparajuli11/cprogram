//Write a program to initialize structure with information of books
//and pass structure variables to a function to print the contents of
//structure.

# include<stdio.h>
#include <string.h>

struct bookInfo{
	
	char writer[100];
	int year;
	char publisher[100];
}book;

void printbookinfo(struct bookInfo b){
	
	printf("The info of the books are \n name of book : %s \n published year:  %d  \n publisher : %s", book.writer, book.year,book.publisher);
	
}

int main(){
	
	strcpy(book.writer,"A Brief Story Time");
	book.year = 1988;
	strcpy(book.publisher,"Golumolu print house");
	printbookinfo(book);
	return 0;
}