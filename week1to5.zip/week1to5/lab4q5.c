//Write a program that allocates memory space as required
// by the user for three arrays. User enters the numbers 
//for two arrays and the program sums the corresponding 
//array elements and stores them in the third array.

# include <stdlib.h>
# include <stdio.h>

int main(){
	
	int value1,value2,value3,*arr1,*arr2,*arr3;
	printf("Enter the total number of values to store in first array");
	scanf("%d", &value1);
	
	printf("Enter the total number of values to store in first array");
	scanf("%d", &value2);
	
	
	arr1 = (int *) malloc (value1*sizeof(int));
	arr2 = (int *) malloc (value2*sizeof(int));
	
	if (arr1 == NULL || arr2 == NULL){
		
		printf("Memory allocation failed");
		
		return 1;
	}	
	
	for(int i=0; i<value1; i++){
		
		printf("Enter the %d numbers to store in first array",i+1);
		scanf("%d", &arr1[i]);
	}
	
	for(int i=0; i<value2; i++){
		printf("Enter the %d numbers to store in last array", i+1);
		scanf("%d", &arr2[i]);
	}
	
	if(value1<value2){
		value3=value1;
	} else{
		
		value3 = value2;
	}
	
	arr3 = (int *)malloc(value3 * sizeof(int));
	
	for(int i=0; i<value3; i++){
		
		arr3[i] = arr1[i]+arr2[i];
	}
	
	printf("Sum of array are : \n");
	
	for(int i=0; i<value3; i++){
		printf("%d ",arr3[i]);
	}
	
	free(arr1);
	free(arr2);
	free(arr3);
	
	return 0;
}