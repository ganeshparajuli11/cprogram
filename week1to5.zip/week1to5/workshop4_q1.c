// C program to create memory for int,
//char and float variables at run time.

#include <stdio.h>
#include <stdlib.h>
int main(){

    // Creating memory for an int variable at runtime
    int *a = (int*)malloc(sizeof(int));

    // Creating memory for a char variable at runtime
    char *b = (char*)malloc(sizeof(char));

    // Creating memory for a float variable at runtime
    float *c = (float*)malloc(sizeof(float));

    // Check if memory allocation was successful
    if (a == NULL || b == NULL || c == NULL) {
        printf("Memory allocation failed. Exiting...\n");
        return 1; // Return an error code
    }

    // Assign values to the variables
    *a = 10;
    *b = 'A';
    *c = 3.14;
 
    // Display the values
    printf("Value of intVariable: %d\n", *a);
    printf("Value of charVariable: %c\n", *b);
    printf("Value of floatVariable: %.2f\n", *c);

    // Free the allocated memory
    free(a);
    free(b);
    free(c);

    return 0; // Return success
}

