// 1. Write a program in C to show the simple structure of a function.

# include <stdio.h>

int sum (int x , int y){
	
	return (x+y);
	
}

int main (){
	
	int a = 23;
	int b = 33;
	int z = sum (a,b);
	
	printf("%d",z);
}
