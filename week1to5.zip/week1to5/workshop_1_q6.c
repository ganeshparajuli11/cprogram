// 6.	Print the following pattern using nested loop:
            //  A
            //  B  B
            //  C  C  C
            //  D  D  D  D
            //  E  E  E  E  E

# include <stdio.h>

int main (){
	
	char c = 'A';
	for (int i =0; i <=4; i++){
		for (int j=0; j<=i; j++){
			int new = c+i;
			printf("%c", new);
		}
		
		printf("\n");
	}
	
	return 0;
}