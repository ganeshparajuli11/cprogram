// Write a program in C to swap two numbers using function.

#include <stdio.h>

// Function to swap two numbers using pointers
int swap(int *a, int *b) {
    // Store the value at the address pointed to by 'a' in a temporary variable
    int swapp = *a;

    // Assign the value at the address pointed to by 'a' with the value at the address pointed to by 'b'
    *a = *b;

    // Assign the value at the address pointed to by 'b' with the temporary variable value
    *b = swapp;

    // Return the original value of 'a'
    return swapp;
}

int main() {
    // Declare two variables to store user input
    int a, b;

    // Prompt the user to enter two numbers
    printf("Enter two numbers: ");
    scanf("%d %d", &a, &b);

    // Display the initial values of 'a' and 'b'
    printf("The value of a was %d and b was %d", a, b);

    // Call the swap function to swap the values of 'a' and 'b'
    swap(&a, &b);

    // Display the updated values of 'a' and 'b' after swapping
    printf(" now value of a is %d and b is %d", a, b);

    return 0;
}
