//Write a C program to search an element in array 
// using pointer.

# include<stdio.h>

int main(){
	
	int arr[4] = {1,2,3,4};
	int n,i, *ptr;
	printf("Enter the element to find");
	scanf("%d",&n);
	ptr = NULL;
	
	for (i =0; i<4; i++){
		
		if (arr[i]==n){
			
			ptr = &arr[i];
			break;
		}
	}
	
	if(ptr != NULL){
		printf("The element (%d) is present in the array",*ptr);
	} else{
		
		printf("The number (%d) is not present in the array",n);
	}
	
	return 0;
}