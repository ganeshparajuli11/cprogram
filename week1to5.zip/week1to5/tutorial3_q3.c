// 3. WAP to sort array elements in ascending order

# include <stdio.h>

#include <stdio.h>

int main() {
    int temp, n = 5;
    int Array[] = {5, 2, 3, 4, 1};

    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (Array[j] > Array[j + 1]) {
                temp = Array[j];
                Array[j] = Array[j + 1];
                Array[j + 1] = temp;
            }
        }
    }

    printf("Sorted array in ascending order: ");
    for (int i = 0; i < n; i++) {
        printf("%d ", Array[i]);
    }
    
    return 0;
}
