// Write a program to ask the final score from user and print it
// whether he/she is passed in (distinction above 80%, first division
// above 60% to 80%, second division above 50% to 60%, Third
// division above 40% to 50%, and fail below 40%). It is mandatory to
// use elseif statement to solve the task.

#include <stdio.h>

int main() {
    int final_score;

    printf("Enter your final score: ");
    scanf("%d", &final_score);

    if (final_score > 80 && final_score <= 100) {
        printf("You have scored distinction\n");
    } else if (final_score > 60 && final_score <= 80) {
        printf("You have scored first division\n");
    } else if (final_score > 50 && final_score <= 60) {
        printf("You have scored second division\n");
    } else if (final_score > 40 && final_score <= 50) {
        printf("You have scored third division\n");
    } else {
        printf("You are failed\n");
    }

    return 0;
}
