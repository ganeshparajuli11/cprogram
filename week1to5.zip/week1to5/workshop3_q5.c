// Write a program to take three numbers from the user and save it in three
// different variables. You must swap the value of three numbers using
// function. You must use call by references.

#include <stdio.h>

 void swap(int *a, int *b, int *c){
	int temp = *a;
	*a = *b;
	*b = *c;
	*c = temp;
	
	printf("The swapped value are %d %d %d", *a,*b,*c);	
}

int main (){
	
	int a,b,c;
	printf("Enter three number ");
	scanf("%d %d %d",&a,&b,&c);
	
	swap(&a,&b,&c);
	
	return 0;
}