// Write a program to print all unique elements 
// in an array. For example,a[ ] ={1,2,4,8,4,2,4,9,6} 
// answer : 1,2,4,8,9,6.

#include <stdio.h>

int main() {
    int a[] = {1, 2, 4, 8, 4, 2, 4, 9, 6};
    int size = sizeof(a) / sizeof(a[0]);

    printf("Unique elements are: ");

    for (int i = 0; i < size; i++) {
        int isUnique = 1;

        for (int j = 0; j < size; j++) {
            if (i != j && a[i] == a[j]) {
                isUnique = 0;
                break;
            }
        }

        if (isUnique) {
            printf("%d ", a[i]);
        }
    }

    return 0;
}
