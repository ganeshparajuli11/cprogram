// WAP reads two 2-D arrays,adds the corresponding 
// elements and displays the result on the screen. 

#include <stdio.h>

