// Declare a structure variable of type team and initialize it with,
//Name: Chicago Bears
//Won: 14
//Lost: 2
//Percentage: 87.5

#include <stdio.h>
# include <string.h>
struct team{
	
	char Name[60];
	int Won;
	int Lost;
	float Percentage;
		
}team1;

int main(){
	
	strcpy(team1.Name,"Chicago Bears");
	team1.Won = 14;
	team1.Lost = 2;
	team1.Percentage = 87.5;
	
	printf("Name of the team %s",team1.Name);
	printf("\nWon game of the team %d",team1.Won);
	printf("\nPercentage game of the team %d",team1.Lost);
	printf("\nLost game of the team %.2f",team1.Percentage);
}