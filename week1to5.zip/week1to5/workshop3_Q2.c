// Write a program to count and find the sum of all the numbers in the array
// which are exactly divisible by 7 and not divisible by 2 and 3.

# include <stdio.h>

int main(){
	
	int arr[] = {7,14, 21, 18, 28, 35, 42, 49, 56, 63};
	int sum=0;
	int size = sizeof(arr)/ sizeof(arr[0]);
	for (int i =0; i<size; i++){
		
		if (arr[i]%7 ==0 && arr[i] % 2 != 0 && arr[i] % 3 != 0){
			
			sum = sum + arr[i];
		}
	}
	
	printf("The sum of all the numbers in the array which are exactly divisible by 7 and not divisible by 2 and 3 is : %d",sum);
	
	return 0;
}