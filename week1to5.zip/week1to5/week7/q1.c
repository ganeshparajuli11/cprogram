//1. Apply a negative filter on an image file.
// This is the process of reversing the RGB values.
//For example, if the Red value of the pixel is 100, 
//the inverse is 155. NOTE: 0 is minimum
//and 255 is maximum.

#include <stdio.h>
#include <stdlib.h>
#include "lodepng.h"

int main(){
    unsigned char *image;
    int h, w, i;
    int error;
    float gray;
    error = lodepng_decode32_file(&image, &w, &h, "xyz.png");
    printf("%d %s\n", error, lodepng_error_text(error));
    printf("%d %d", h, w);
    for (i = 0; i < h; i++){
        for (int j = 0; j < w; j++)
        {
            int red = image[4*w*i + 4*j+0];
            int green = image[4*w*i + 4*j+1];
            int blue = image[4*w*i + 4*j+2];
            int alpha = image[4*w*i + 4*j+3];
            gray = (red+blue+green)/3;
            image[4*w*i + 4*j+0] = gray;
            image[4*w*i + 4*j+1] = gray;
            image[4*w*i + 4*j+2] = gray;
        }

    }
    unsigned char *output;
    size_t outputsize;
    error = lodepng_encode32(&output, &outputsize, image, w, h);
    if (!error){
        lodepng_save_file(output,outputsize, "output.png");
    }
    free(image);
    
    return 0;
}