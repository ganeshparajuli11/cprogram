#include <stdio.h>
#include <stdlib.h>
#include "lodepng.h"

int main() {
    unsigned char* image;
    int height,width,i;
    
    lodepng_decode32_file(&image, &width, &height, "image.png");
    printf("%d %d\n", width,height);
    
    for (i=0; i<height*width*4; i=i+4){
    	
    	printf("%d %d %d %d\n",image[i+0], image[i+1], image[i+2], image[i+3]);
    	
	}
	
	free(image);
    return 0;
}
