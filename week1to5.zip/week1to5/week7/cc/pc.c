#include <stdio.h>
#include <stdlib.h>
#include "lodepng.h"

int main() {
    unsigned char *image;
    unsigned int width, height;
    unsigned int error;
    int red, green, blue, alpha;

    // Decode the input PNG image
    error = lodepng_decode32_file(&image, &width, &height, "xyz.png");

    if (error) {
        fprintf(stderr, "Error %u: %s\n", error, lodepng_error_text(error));
        return 1;
    }

    // Modify the image (setting blue channel to 255 for all pixels)
    for (int i = 0; i < height; i++) {
        for (int j = 0; j < width; j++) {
            red = image[4 * width * i + 4 * j + 0];
            green = image[4 * width * i + 4 * j + 1];
            green = 255;  // Set blue channel to 255
            alpha = image[4 * width * i + 4 * j + 3];

            image[4 * width * i + 4 * j + 2] = green;
        }
    }
    

    // Encode and save the modified image as a new PNG file
    unsigned char *output;
    size_t outputsize;
    error = lodepng_encode32(&output, &outputsize, image, width, height);

    if (!error) {
        lodepng_save_file(output, outputsize, "output.png");
        printf("Image successfully encoded and saved as output.png\n");
    } else {
        fprintf(stderr, "Error %u: %s\n", error, lodepng_error_text(error));
    }

    free(image);
    free(output);

    return 0;
}
