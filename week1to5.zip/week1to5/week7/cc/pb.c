#include <stdlib.h>
#include <stdio.h>
#include "lodepng.h"

int main() {
    unsigned char *image;
    unsigned int width, height, red, green, blue, alpha;

    lodepng_decode32_file(&image, &width, &height, "image.png");
    int i, j;

    for (i = 0; i < height; i++) {
        for (j = 0; j < width; j++) {
            red = image[4 * width * i + 4 * j + 0];
            green = image[4 * width * i + 4 * j + 1];
            blue = image[4 * width * i + 4 * j + 2];
            alpha = image[4 * width * i + 4 * j + 3];

            printf("%d %d %d %d\n", red, green, blue, alpha);
        }
    }

    free(image);
    return 0;
}
