#include <stdio.h>
#include "lodepng.h"
#include <stdlib.h>
int main(){
	unsigned char *image;
	unsigned int width,height;
	lodepng_decode32_file(&image,&width,&height,"test1.png");
	printf("%d %d",width,height);
	int i;
	for(i=0;i<width*height*4;i=i+4){
		printf("\nRed:%d Green:%d Blue:%d Alpha:%d\n",image[i+0],image[i+1],image[i+2],image[i+3]);
	}
	free(image);
	return 0;
}