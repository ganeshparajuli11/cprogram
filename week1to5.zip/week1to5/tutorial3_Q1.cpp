// WAP to swap the number using (call by value and call by reference).

#include <stdio.h>

void callbyValue(int a, int b){ // taking value by calling
	int temp = a;
	a = b;
	b = temp;
	
	printf(" This swapping is done by call by value method %d %d \n",a,b);
}

void passbyRefrence(int *c, int *d){
	
	int temp = *c;
	*c = *d;
	*d = temp;
	
	printf(" This swapping is done by call by refrence method %d %d",*c,*d);
	
}


int main(){
	
	int num1,num2;
	printf("Enter two numbers");
	scanf("%d %d",&num1,&num2);
	
	callbyValue(num1,num2); // call by values 
	passbyRefrence(&num1,&num2); //  pass by value
	
	return 0;
}