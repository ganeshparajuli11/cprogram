//C program to create memory for int, char and float 
//variables at run
//time.

# include<stdio.h>
# include<stdlib.h>

int main() {
	
    int num1 = 1; 
    float num2 = 1.08; 
    char c = 'A';
    int *ptr1; 
    float *ptr2;
    char *ptr3;
	
    ptr1 = (int *)malloc(num1 * sizeof(int));
    ptr2 = (float *)malloc(sizeof(float));
    ptr3 = (char *)malloc(sizeof(char));
	
    if (ptr1 == NULL || ptr2 == NULL || ptr3 == NULL) {
        printf("Memory allocation failed");
    } else {
        printf("Successful memory allocation\n");
    }

    *ptr1 = num1;
    *ptr2 = num2;
    *ptr3 = c;

    printf("%d %c %f", *ptr1, *ptr3, *ptr2);

    free(ptr1);
    free(ptr2);
    free(ptr3);
	
    return 0;
}
