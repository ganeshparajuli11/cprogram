#include <stdio.h>
#include <pthread.h>

struct num{
	
	int a,b;
};

int r1,r2;

void* add(void* p){
	
	struct num* n1 = (struct num*)p;
	
	r1 = n1 ->a+ n1 ->b;
	pthread_exit(&r1);
}

void* multiply(void* p){
	
	struct num* n2 = (struct num*)p;
	
	r1 = n2 ->a * n2 ->b;
	pthread_exit(&r2);
}

int main(){
	
	struct num n;
	n.a = 5;
	n.b = 10;
	
	pthread_t t1,t2;
	pthread_create (&t1,NULL,add,&n);
	pthread_create (&t1,NULL,multiply,&n);
	void* result1;
	void* result2;
	
	pthread_join(t1,&result1);
	pthread_join(t2,&result2);
	
	printf("Addition : %d , Multiply: %d", *(int *)result1,*(int *)result2);
	return 0;
}