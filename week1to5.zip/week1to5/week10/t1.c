#include <stdio.h>
#include <pthread.h>

int a =10;
void* fun(void *p){
	
	pthread_exit((void *)&a);
}

int main(){
	
	pthread_t t1;
	pthread_create (&t1,NULL,fun,NULL);
	
	void* r;
	printf("Integer: %d", *(int *)r);
	
	return 0;
}
