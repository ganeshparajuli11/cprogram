#include <stdio.h>
#include <pthread.h>

struct sqNum {
    int start, end;
};

int sqList[1000];

void* squareNumber(void* p) {
    struct sqNum* snum = (struct sqNum*)p;
    int first = snum->start;
    int last = snum->end;

    for (int i = first; i <= last; i++) {
        sqList[i] = i * i;
    }

    return NULL;
}

int main() {
    int dataCount = 1000;
    int threadCount = 3;
    int remainder = dataCount % threadCount;
    int sliceList[threadCount];

    for (int i = 0; i < threadCount; i++) {
        sliceList[i] = dataCount / threadCount;
    }

    for (int i = 0; i < remainder; i++) {
        sliceList[i] = sliceList[i] + 1;
    }

    for (int i = 0; i < threadCount; i++) {
        printf("%d\n", sliceList[i]);
    }

    int startList[threadCount];
    int endList[threadCount];

    for (int i = 0; i < threadCount; i++) {
        if (i == 0) {
            startList[i] = 0;
        } else {
            startList[i] = endList[i - 1] + 1;
        }

        endList[i] = startList[i] + sliceList[i] - 1;
    }

    struct sqNum s[threadCount];

    for (int i = 0; i < threadCount; i++) {
        s[i].start = startList[i];
        s[i].end = endList[i];
    }

    pthread_t threadIds[threadCount];

    for (int i = 0; i < threadCount; i++) {
        pthread_create(&threadIds[i], NULL, squareNumber, &s[i]);
    }

    for (int i = 0; i < threadCount; i++) {
        pthread_join(threadIds[i], NULL);
    }

    for (int i = 0; i < dataCount; i++) {
        printf("%d\n", sqList[i]);
    }

    return 0;
}
