#include <stdio.h>
#include <pthread.h>
#include <Windows.h>

int shared =10;

void* fun1(void* p){
	
	int x = shared;
	x++ ;
	Sleep(1000);
	x = shared;
}

void* fun2(void* q){
	
	int y = shared;
	y-- ;
	Sleep(1000);
	y = shared;
}

int main(){
	
	pthread_t t1,t2;
	pthread_create(&t1,NULL,fun1,NULL);
	pthread_create(&t2,NULL,fun1,NULL);
	pthread_join(t1,NULL);
	pthread_join(t2,NULL);
	printf("%d\n",shared);
	
	return 0;
}