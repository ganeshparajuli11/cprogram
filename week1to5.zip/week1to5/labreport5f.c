//Create a structure named Employee having members name, salary
//and hours of work per day. Now, write a program to dynamically 
//create an ‘n’ number of structures of type Employee. Pass this 
//array of structure to a function that prints the highest salary 
//of the employee.

#include <stdio.h>

struct Employee {
    char name[50];
    int salary;
    int workingHourperDay;
};

void printHighestSalary(struct Employee employ[], int n) {
    int maxSalary = employ[0].salary;
    int maxIndex = 0;

    for (int i = 1; i < n; i++) {
        if (employ[i].salary > maxSalary) {
            maxSalary = employ[i].salary;
            maxIndex = i;
        }
    }

    printf("Details of the highest earning person:\n");
    printf("Name: %s\n", employ[maxIndex].name);
    printf("Salary: %d\n", employ[maxIndex].salary);
    printf("Working Hours per Day: %d\n", employ[maxIndex].workingHourperDay);
}

int main() {
    int n;

    printf("Enter the number of employees: ");
    scanf("%d", &n);
	
	struct Employee *ptr = (struct Employee *)malloc(n*sizeof(struct Employee));
	
//    struct Employee employ[n];

    for (int i = 0; i < n; i++) {
        printf("Enter name of %d person: ", i + 1);
        scanf("%s", (ptr+i)->name);

        printf("Enter salary: ");
        scanf("%d", & (ptr+i)->salary);

        printf("Enter no of working hours: ");
        scanf("%d", & (ptr+1)-> workingHourperDay);
    }

    printHighestSalary(*ptr, n);
	
	free(employ);
    return 0;
}


