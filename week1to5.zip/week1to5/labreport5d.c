//Create a structure name Student and inside that struct 
//include two data members' roll no and marks, inside that
//struct student definition create another struct named
//student_info where you should include three data members' 
//name, age, and dateof birth and print it out for 3 students.

#include <stdio.h>

struct StudentInfo {
    char name[50];
    int age;
    char dateOfBirth[50];
};

struct Student {
    int rollNo;
    float marks;
    struct StudentInfo info; 
};

int main() {
    struct Student stud[3];

    for (int i = 0; i < 3; i++) {
        printf("Enter name of %d student: ", i + 1);
        scanf("%s", stud[i].info.name);

        printf("Enter age: ");
        scanf("%d", &stud[i].info.age);

        printf("Enter date of birth in DD/MM/YYYY: ");
        scanf("%s", stud[i].info.dateOfBirth);

        printf("Enter roll no: ");
        scanf("%d", &stud[i].rollNo);

        printf("Enter marks: ");
        scanf("%f", &stud[i].marks);
    }

    printf("Printing details of 3 students\n");

    for (int i = 0; i < 3; i++) {
        printf("Name: %s\n", stud[i].info.name);
        printf("Age: %d\n", stud[i].info.age);
        printf("Date of birth: %s\n",stud[i].info.dateOfBirth);
        printf("Roll no: %d\n", stud[i].rollNo);
        printf("Marks: %.2f\n", stud[i].marks);
    }

    return 0;
}
