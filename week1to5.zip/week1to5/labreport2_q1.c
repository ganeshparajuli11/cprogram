// Write a C program to find cube of a number 
//using function.

# include <stdio.h>
int cube(int a){
	
	int cubeAns = a*a*a;
	
	return cubeAns;
}

int main(){
	
	int a;
	printf("Enter a number to find cube ");
	scanf("%d",&a);
	
	int answer = cube(a);
	
	printf("The cube of %d is %d\n",a,answer);
	
	return 0;
}