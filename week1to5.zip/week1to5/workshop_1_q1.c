//1.	Write a program to find the sum of numbers from 1 to 10.

#include <stdio.h>

int main (){
	
	int sum = 0;
	for (int i=1; i<=10; i++){
		
		sum=sum+i;
	}
	printf("The sum of first 10 number is: %d" ,sum);
	
	return 0;
}

