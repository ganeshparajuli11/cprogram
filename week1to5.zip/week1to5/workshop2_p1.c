// Write a void function which finds and prints the midpoint coordinates of a line. The
// function should take in four parameters (x1, y1, x2 and y2).
// xmid=(x1+x2)/2, ymid=(y1+y2)/2

# inculude <stdio.h>

void midpoint(){
	
	
}