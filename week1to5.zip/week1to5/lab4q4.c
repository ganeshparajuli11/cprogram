// Finding maximum in an array using dynamic 
// memory allocation.

#include<stdio.h>
#include<stdlib.h>

int main(){
	int *arr;
	int size = 5;
	arr = (int *)malloc(size * sizeof(int));
	
	arr[0] = 4;
	arr[1] = 9;
	arr[2] = 3;
	arr[3] = 5;
	arr[4] = 3;
	
	int max = arr[0];
	for(int i=0; i<4; i++){
		
		if (arr[i] > max){
			
			max = arr[i];
			
		}
		
	}
	
	printf("The maximum number is %d",max);
	
	free(arr);
	return 0;
}