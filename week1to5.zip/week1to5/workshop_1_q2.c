//2.	Write a program to find the factorial of a number.

#include <stdio.h>

int main (){
	
	int num, fact = 1;
	printf("Enter a number to find factorial");
	scanf("%d",&num);
	
	for (int i =1; i<=num; i++ ){
		fact = fact *i;
	}
	
	printf("The factorial of given number is : %d", fact);
	
	return 0;
 	
}