// Write a program to count and find the sum of all the 
// numbers in the array which are exactly divisible by 
// 5 and not divisible by 2 and 3.

void calc(int arr [],int size){
	
	int found = 0;
	int sum =0;
	
	for (int i =0; i<size; i++){
		if(arr[i] % 5 == 0 && arr[i] % 2 != 0 && arr[i] % 3 != 0 ){
			
			sum = sum +arr[i];
			found = 1;
		}
	}
	
	if(found){
		
		printf("The sum of all numbers in the array which are exactly divisible by 5 and not divisible by 2 and 3 is : %d\n",sum);

	} else{
		
		printf("No numbers match the condition\n");
	}
	
}

int main(){
	
	int arr1 [] ={2,8,9,4,5};
	int size = sizeof(arr1)/sizeof(arr1[0]);
	
	calc(arr1,size);
	
	return 0;
}