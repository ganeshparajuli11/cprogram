// Add a new function in the program you have created 
// in Qno. 3 which takes three parameters: an array, 
// length of the array and value to replace each element
// in an array. You must receive an integer value in the
// main function. Your function should not return anything 
// and it should not print anything. You must print a
// new array in the main function.

# include <stdio.h>

#include <stdio.h>

void arryValue(int arr[], int size, int replace) {

    for (int i = 0; i < size; i++) {
        arr[i] = replace;
    }

    printf("Updated array elements: ");
    for (int i = 0; i < size; i++) {
        printf("%d ", arr[i]);
    }
    
    printf("\n");
}

int main() {
    int size;
    printf("Enter the length size of array: ");
    scanf("%d", &size);
	
    int array[size];
	
    for (int i = 0; i < size; i++) {
        printf("Enter the %d element to store in array: ", i + 1);
        scanf("%d", &array[i]);
    }
	
	int replace;
	printf("Enter the replacing values");
	scanf("%d", &replace);
	
    printf("Original array elements: ");
    for (int i = 0; i < size; i++) {
        printf("%d ", array[i]);
    }
    
    printf("\n");

    arryValue(array, size, replace);
    return 0;
}