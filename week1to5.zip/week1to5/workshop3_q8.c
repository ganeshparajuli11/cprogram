// Write a program to replace each element in an array with 
// the integer value 5.You must take input from users in the
// main function and save it in an array.You must also 
// take the size of an array from the user. You must 
// create a function that takes two parameters: an array 
// and length of the array. You function should not return 
// anything and it should not print anything. You must 
//print before and after replacing an element in an array 
// in the main function.

#include <stdio.h>

void arryValue(int arr[], int size) {
    int replace = 5;


    for (int i = 0; i < size; i++) {
        arr[i] = replace;
    }

    printf("Updated array elements: ");
    for (int i = 0; i < size; i++) {
        printf("%d ", arr[i]);
    }
    
    printf("\n");
}

int main() {
    int size;
    printf("Enter the length size of array: ");
    scanf("%d", &size);

    int array[size];

    for (int i = 0; i < size; i++) {
        printf("Enter the %d element to store in array: ", i + 1);
        scanf("%d", &array[i]);
    }

    printf("Original array elements: ");
    for (int i = 0; i < size; i++) {
        printf("%d ", array[i]);
    }
    
    printf("\n");

    arryValue(array, size);
    return 0;
}
