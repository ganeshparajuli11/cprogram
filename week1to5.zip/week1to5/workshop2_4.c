// Write a function named “velocityCalc” which returns an appropriate value for the
// formula “v=u+at”, where v is the final velocity, u is the initial velocity ,a is the
// acceleration and t is the time that has elapsed. Depending upon which variable is set to
// “NAN” when the function is called , your function should work it out and return the
// value.

# include <stdio.h>
# include <math.h>
float velocityCalc(float u,float v,float t){
	
	float a = 9.8;
	
	
	if (isnan(v)){
		
		float v = u+a*t;
		
		return v;
	} else if (isnan(u)){
		
		float u = v-a*t;
		
		return u;
	} else if (isnan(t)){
		
		float t = ((v-u)/a);
		
		return t;
	} else{
		
		return NAN;
	}
	
}

int main (){
	
	float u,a,t;
	printf("Enter inital velocity u");
	scanf("%f",&u);
	
	printf("Enter time t");
	scanf("%f",&t);
	
	float finalVelocity = velocityCalc(u,NAN,t);
	
	printf("%.2f",finalVelocity, "m/s %d");
	
	return 0;
}