// Write a program to initialize an integer array with values {10,5,7,91,54,24}.
// Pass this array to a function. If element is found, print out its index number 
// and if element is not found then display the message “Element Not found” in
// the function.

#include <stdio.h>

void findElement(int arr[], int size, int element) {
    int found = 0;

    for (int i = 0; i < size; i++) {
        if (arr[i] == element) {
            printf("%d element is found at index %d\n", element, i);
            found = 1;
            break; 
        }
    }

    if (!found) {
        printf("%d element is not found\n", element);
    }
}

int main() {
    int arr[] = {10, 5, 7, 91, 54, 24};
    int size = sizeof(arr) / sizeof(arr[0]);
    int element;

    printf("Enter the number to find: ");
    scanf("%d", &element);

    findElement(arr, size, element);

    return 0;
}
