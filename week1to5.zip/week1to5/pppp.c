struct Student{
	
	int age;
	int rollno;
}stud;

int main(){
	
	stud.age = 15;
	
	printf("%d",stud.age);
}