// Write a void function which takes one integer (n) as a parameter. Your function should
// then print out all triangular numbers from 1 up to the nth term.

# include <stdio.h>

void integer(int n){
	
	int trang=0;
	
	for (int i =0; i<=n; i++){
		
		trang = trang +i;
		
		printf("%d\n",trang);
	}
}

int main(){
	
	int n;
	printf("Enter nth value to find the greatest number");
	scanf("%d",&n);
	
	integer(n);
}