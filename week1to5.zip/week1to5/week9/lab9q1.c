//1. Write a program that creates two threads to display the 
//numbers from 1-1000. The two
//threads should equally contribute to display the numbers.

#include <stdio.h>
#include <pthread.h>


void *threadOne(void *p){
	
	for(int i=0; i<=500; i++ ){
		
		printf("Number from one to hundred are create in this thread %d\n",i);
	}
	
	pthread_exit(NULL);
}

void *threadTwo(void *p){
	
	for(int i=501; i<=1000; i++){
		
		printf("The remaining number from 501 to 1000 are print in this thread %d\n",i);
	}
	
	pthread_exit(NULL);
}

int main(){
	
	pthread_t thread1,thread2;
	
	pthread_create(&thread1,NULL,threadOne,NULL);
	pthread_create(&thread2,NULL,threadTwo,NULL);
	
	pthread_join(thread1,NULL);
	pthread_join(thread2,NULL);
	
	return 0;
}