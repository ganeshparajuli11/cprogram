#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>  // Added for dynamic memory allocation



//One

// void* threadOne(){
//     int start = 1;
//     int end = 500;

//     while(start<=end){
//         printf("ThreadOne: %d\n",start);
//         start++;
//     }
// }

// void* threadTwo(){
//     int start = 501;
//     int end = 1000;

//     while(start<=end){
//         printf("ThreadTwo: %d\n",start);
//         start++;
//     }
// }

// int main(){
//     pthread_t t1, t2;
//     pthread_create(&t1, NULL, threadOne, NULL);
//     pthread_create(&t2, NULL, threadTwo, NULL);

//     pthread_join(t1, NULL);
//     pthread_join(t2, NULL);
// // }

// // Two


// #include <stdio.h>
// #include <pthread.h>
// #include <stdlib.h>  // Added for dynamic memory allocation

// typedef struct {
//     int threadId;
//     int start;
//     int end;
// } threadValues;

// int isPrime(int num) {
//     for (int i = 2; i < num; i++) {
//         if (num % i == 0) {
//             return 0;
//         }
//     }
//     return 1;
// }

// void* printValue(void* values) {
//     threadValues* store = (threadValues*)values;
//     for (int i = store->start; i <= store->end; i++) {
//         if (isPrime(i) == 1) {
//             printf("Thread%d: %d\n", store->threadId, i);
//         }
//     }
//     free(store);  // Free the allocated memory
//     return NULL;
// }

// int main() {
//     int threads = 2;
//     pthread_t t[threads];

//     for (int i = 0; i < threads; i++) {
//         threadValues* th = (threadValues*)malloc(sizeof(threadValues));
//         th->start = 1 + (i * (500 / threads));
//         th->end = (i + 1) * (500 / threads);
//         th->threadId = i + 1;
//         pthread_create(&t[i], NULL, printValue, th);
//     }

//     for (int i = 0; i < threads; i++) {
//         pthread_join(t[i], NULL);
//     }

//     return 0;
// }

// 3
typedef struct{
    int start;
    int end;
    int threadId;
}threadValues;

void* display(void* values){
    threadValues* val = (threadValues *) values;
    for(int i=val->start; i<=val->end; i++){
        printf("Thread%d: %d\n",val->threadId, i);
    }
    return NULL;
}

int main(){
    pthread_t t[5];
    for(int i = 0; i<5; i++){
        threadValues *th = (threadValues *) malloc(sizeof(threadValues));
        th->start = i*200 + 1;
        th->end = (i+1)*200;
        th->threadId = i+1;
        pthread_create(&t[i], NULL, display, th);
    }
    for(int i = 0; i<5; i++){
        pthread_join(t[i], NULL);
    }
    return 0;
}

// 4
typedef struct{
    int start;
    int end;
    int threadId;
}threadValues;

int count=0;

void* display(void* values){
    threadValues* val = (threadValues *) values;
    for(int i=val->start; i<=val->end; i++){
        printf("Thread%d: %d\n",val->threadId, i);
        count++;
    }

    return NULL;
}

int main(){
    int threads;
    printf("Enter number of threads you want");
    scanf("%d", &threads);
    pthread_t *t = (pthread_t *) malloc(threads*sizeof(pthread_t));
    for(int i = 0; i<threads; i++){
        threadValues *th = (threadValues *) malloc(sizeof(threadValues));
        th->start = i*(1000/threads) + 1;
        if((i+1)==threads){
            th->end = 1000;
        }else{
            th->end = (i+1)*(1000/threads);
        }
        th->threadId = i+1;
        pthread_create(&t[i], NULL, display, th);
    }
    for(int i = 0; i<threads; i++){
        pthread_join(t[i], NULL);
    }
    printf("Final count: %d", count);
    return 0;
}


// // 5
typedef struct{
    int start;
    int end;
    int threadId;
}threadValues;

int count=0;

int isOdd(int num){
    if(num%2==1){
        return 1;
    }
    return 0;
}

void* display(void* values){
    threadValues* val = (threadValues *) values;
    for(int i=val->start; i<=val->end; i++){
        if(isOdd(i)==1){
            printf("Thread%d: %d\n",val->threadId, i);
            count++;

        }
    }

    return NULL;
}

int main(){
    int threads;
    printf("Enter number of threads you want");
    scanf("%d", &threads);
    pthread_t *t = (pthread_t *) malloc(threads*sizeof(pthread_t));
    for(int i = 0; i<threads; i++){
        threadValues *th = (threadValues *) malloc(sizeof(threadValues));
        th->start = i*(1000/threads) + 1;
        if((i+1)==threads){
            th->end = 1000;
        }else{
            th->end = (i+1)*(1000/threads);
        }
        th->threadId = i+1;
        pthread_create(&t[i], NULL, display, th);
    }
    for(int i = 0; i<threads; i++){
        pthread_join(t[i], NULL);
    }
    printf("Final count: %d", count);
    return 0;
}


int result=0;
typedef struct{
    int start;
    int stop;
    int *ar;
    int userInput;
}data;


int checkExist(int start, int end, int *arr, int input){
    for(int i = start; i<end; i++){
        if(input==arr[i]){
            return 1;
        }
    }
    return 0;
}



void* search(void* pass){
    data *st = (data *) pass;
    result += checkExist(st->start,st->stop,st->ar,st->userInput);
}

int main(){
    data sh,th;
    int arr[] = {1,2,3,4,5,6,7,8}, num;
    printf("Enter the number you wantto search for: ");
    scanf("%d", &num);
    int size = 8;
    int mid = size/2;
    pthread_t t1, t2;
    sh.start = 0;
    sh.stop = mid;
    sh.userInput = num;
    sh.ar = arr;
    pthread_create(&t1, NULL, search, &sh);
    th.start = mid;
    th.stop = size;
    th.userInput = num;
    th.ar = arr;
    pthread_create(&t2, NULL, search, &th);
    pthread_join(t1, NULL);
    pthread_join(t2, NULL);

    if(result>=1){
        printf("Yes, the number exist.");
    }else{
        printf("No, the number dont exist.");
    }

    return 0;
}