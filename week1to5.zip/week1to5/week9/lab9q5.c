//Create a multithreaded program to display all the odd 
//numbers from 1-1000. Your program should ask the user to 
//input the number of threads. Based on the number of
//threads you should divide the workload among the threads

#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>

typedef struct{
    int start;
    int end;
    int threadId;
    
}threadValues;

int count=0;

int isOdd(int num){
    if(num%2==1){
        return 1;
    }
    return 0;
}

void* display(void* values){
    threadValues* val = (threadValues *) values;
    for(int i=val->start; i<=val->end; i++){
        if(isOdd(i)==1){
            printf("Thread%d: %d\n",val->threadId, i);
            count++;

        }
    }

    return NULL;
}

int main(){
	
    int threads;
    printf("Enter number of threads you want");
    scanf("%d", &threads);
    pthread_t *t = (pthread_t *) malloc(threads*sizeof(pthread_t));
    for(int i = 0; i<threads; i++){
        threadValues *th = (threadValues *) malloc(sizeof(threadValues));
        th->start = i*(1000/threads) + 1;
        if((i+1)==threads){
            th->end = 1000;
        }else{
            th->end = (i+1)*(1000/threads);
        }
        th->threadId = i+1;
        pthread_create(&t[i], NULL, display, th);
    }
    for(int i = 0; i<threads; i++){
        pthread_join(t[i], NULL);
    }
    printf("Final count: %d", count);
    return 0;
}
