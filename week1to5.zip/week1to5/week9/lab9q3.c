//Write a program that creates 5 threads to display the 
//numbers from 1-1000.The five threads should equally 
//contribute to display the numbers.

#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>

typedef struct{
    int start;
    int end;
    int threadId;
}threadValues;

void* display(void* values){
    threadValues* val = (threadValues *) values;
    for(int i=val->start; i<=val->end; i++){
        printf("Thread%d: %d\n",val->threadId, i);
    }
    return NULL;
}

int main(){
    pthread_t t[5];
    for(int i = 0; i<5; i++){
        threadValues *th = (threadValues *) malloc(sizeof(threadValues));
        th->start = i*200 + 1;
        th->end = (i+1)*200;
        th->threadId = i+1;
        pthread_create(&t[i], NULL, display, th);
    }
    for(int i = 0; i<5; i++){
        pthread_join(t[i], NULL);
    }
    return 0;
}