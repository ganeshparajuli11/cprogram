//6. Create a program to search an element from an array 
//using multithreading. If the element is found print element 
//found else print element not found.

#include <stdio.h>
#include <pthread.h>

typedef struct student {
    char name[50];
    int age;
    int id;
    
} info;

int isElementFound(info *array, int size, int target) {
    for (int i = 0; i < size; i++) {
        if (array[i].id == target) {
            return 1; // Element found
        }
    }
    return 0; // Element not found
}

void *search(void *p) {
    info *infoArray = (info *)p;
    int target;

    printf("Enter the ID to search: ");
    scanf("%d", &target);

    if (isElementFound(infoArray, 5, target)) {
        printf("Element found!\n");
    } else {
        printf("Element not found!\n");
    }

    pthread_exit(NULL);
}

int main() {
    info infoArray[5] = {
        {"Ramesh Chalise", 18, 12},
        {"John Doe", 20, 15},
        {"Jane Smith", 22, 20},
        {"Alice Johnson", 19, 25},
        {"Bob Williams", 21, 30}
    };

    pthread_t thread1, thread2;
    pthread_create(&thread1, NULL, search, infoArray);
    pthread_create(&thread2, NULL, search, infoArray);

    pthread_join(thread1, NULL);
    pthread_join(thread2, NULL);

    return 0;
}
