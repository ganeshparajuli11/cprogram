//Write a program that creates two threads to display all 
//the prime numbers from 1-500. The two threads should 
//equally contribute to display the numbers.

#include <pthread.h>
#include <stdio.h>
#include <stdbool.h>

// Function to check if a number is prime
bool isPrime(int num) {
    if (num < 2) {
        return false;
    }
    for (int i = 2; i * i <= num; i++) {
        if (num % i == 0) {
            return false;
        }
    }
    return true;
}

// Function for the first thread to print prime numbers from 1 to 250
void *threadOne(void *p) {
    for (int i = 1; i <= 250; i++) {
        if (isPrime(i)) {
            printf("Thread 1: %d\n", i);
        }
    }
    pthread_exit(NULL);
}

// Function for the second thread to print prime numbers from 251 to 500
void *threadTwo(void *p) {
    for (int i = 251; i <= 500; i++) {
        if (isPrime(i)) {
            printf("Thread 2: %d\n", i);
        }
    }
    pthread_exit(NULL);
}

int main() {
    pthread_t thread1, thread2;

    // Create two threads
    pthread_create(&thread1, NULL, threadOne, NULL);
    pthread_create(&thread2, NULL, threadTwo, NULL);

    // Wait for both threads to finish
    pthread_join(thread1, NULL);
    pthread_join(thread2, NULL);

    return 0;
}
