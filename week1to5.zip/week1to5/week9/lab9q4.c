//Convert program no.3 to accept an integer to specify the 
//number of threads and then create that number of threads 
//dynamically. All the threads will equally contribute to
//display the numbers from 1-1000.



#include <stdio.h>
#include <pthread.h>

void *threads(void *p) {
    int threadValue = *(int *)p;
    int numThreads = *((int *)p + 1);

    // Calculate the range for each thread
    int numPerThread = 1000 / numThreads;
    int start = threadValue * numPerThread + 1;
    int end = (threadValue + 1) * numPerThread;

    // Adjust the last thread's range to cover the remaining numbers
    if (threadValue == numThreads - 1) {
        end = 1000;
    }

    for (int i = start; i <= end; i++) {
        printf("Thread %d: %d\n", threadValue + 1, i);
    }

    pthread_exit(NULL);
}

int main() {
    int numThread;
    printf("Enter the number of threads you want to create: ");
    scanf("%d", &numThread);

    pthread_t threads1[numThread];
    int thread_ids[numThread][2];

    for (int i = 0; i < numThread; i++) {
        thread_ids[i][0] = i;
        thread_ids[i][1] = numThread;

        if (pthread_create(&threads1[i], NULL, threads, &thread_ids[i]) != 0) {
            printf("Error creating thread");
            return 1;
        }
    }

    // Joining threads
    for (int i = 0; i < numThread; i++) {
        pthread_join(threads1[i], NULL);
    }

    printf("Threads printing completed\n");

    return 0;
}
