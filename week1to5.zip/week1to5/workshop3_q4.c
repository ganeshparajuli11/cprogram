// Write a program to read three integers using an array and find the smallest
// and largest among them.You must write a function for finding the largest and
// smallest integer and the result must be displayed in the main function itself.
// You are not allowed to create global variables.

#include <stdio.h>

void largest(int arr1[], int size ){
	
	int max = arr1[0];
	for(int i=0; i<size; i++){
		
		if (arr1[i]>max){
			
			max = arr1[i];
		}
	}
	
	printf("The maximum value in the array is %d",max);
}

int smallest (int arr2[], int size){
	
	int min = arr2[0];
	for (int i =0; i<size; i++){
		
		if (arr2[i]<min){
			
			min = arr2[i];
		}
	}
	
	printf("\nThe minimum value in the array is %d",min);
}

int main(){
	
	int arr[3];
	
	int size = sizeof(arr)/sizeof(arr[0]);
	
	for( int i =0; i<3; i++){
		
		printf("Enter three integer number");
		scanf("%d", &arr[i]);
	}
	
	largest(arr, size);
	smallest(arr,size);
	
	return 0;
}
