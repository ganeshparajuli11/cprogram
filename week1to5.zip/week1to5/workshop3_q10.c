// Write a program in C to take two numbers from the 
// user and print the minimum between two numbers 
// using a pointer.

# include <stdio.h>

int maxMin(int *a, int *b){
	
	if (*a>*b){
		
		printf("Maximum number is %d\n",*a);
		printf("Miniimum number is %d\n",*b);
		
	} else if (*b > *a){
		
		printf("Maximum number is %d\n",*b);
		printf("Minimum number is %d",*a);
	} 
}

int main(){
	
	int a,b;
	
	printf("Enter two numbers");
	scanf("%d %d",&a,&b);
	maxMin(&a,&b);
}