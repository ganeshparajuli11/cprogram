#include <stdio.h>

struct Employee {
    char name[50];
    char post[50];
    int salary;
};

struct Employee* filterEmployee(struct Employee allEmployee[], int numEmployee, int* count) {
    struct Employee filteredEmployee[10];
    *count = 0;

    for (int i = 0; i < numEmployee; i++) {
        if (allEmployee[i].salary > 10000) {
            filteredEmployee[*count] = allEmployee[i];
            (*count)++;
        }
    }

    struct Employee* result = filteredEmployee;
    return result;
}

int main() {
    struct Employee employee[10];

    for (int i = 0; i < 10; i++) {
        printf("Enter name, post, and salary for employee %d:\n", i + 1);
        scanf("%s %s %d", employee[i].name, employee[i].post, &employee[i].salary);
    }

    int count;
    struct Employee* filteredResult = filterEmployee(employee, 10, &count);

    printf("Persons with salary 10k plus are:\n");

    for (int i = 0; i < count; i++) {
        printf("Name: %s\n", filteredResult[i].name);
        printf("Post: %s\n", filteredResult[i].post);
        printf("Salary: %d\n", filteredResult[i].salary);
    }

    return 0;
}
