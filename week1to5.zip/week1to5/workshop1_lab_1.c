//Write a program to create simple calculator using switch case. (The
//operators +, -, *, /and % must be asked to user as a character.)

# include <stdio.h>

int main(){
	
	char operation;
	int a,b;
	
	printf("Enter an operator +, -, *, / and %  ");
	scanf("%c",&operation);
	
	printf("Enter two number ");
	scanf("%d" "%d",&a, &b);
	
	switch (operation)
	{
		
		case '+':
			printf("The sum of two number is : %d\n  ",a+b);
			break;
		
			case '-':
			printf("The different of two number is :  %d\n  ",a-b);
			break;
			
			case '*':
			printf("The product of two number is : %d\n  ",a*b);
			break;
			
			case '/':
			printf("The divide of two number is : %d\n  ",a/b);
			break;
			
			case '%':
			printf("The modulus of two number is : %d\n  ",a%b);
			break;
			
			default:
				printf("Your operator is not correct");
	}
	
	return 0;
	
}
