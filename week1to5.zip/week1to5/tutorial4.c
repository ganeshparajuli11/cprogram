
	
//	int A[5];
//	int *p;
//	
//	p=A;
//	
//	for(int i=0; i<5; i++){
//		
//		printf("Enter %d element to store in array",i+1);
//		scanf("%d",p+i);
//	}
//	
//	printf("print: \n");
//	for(int i=0; i<5; i++){
//		
//		printf("%d  ",A[i]);
//	}


#include <stdio.h>
#include <stdlib.h>

int add(int A[5]) {
    int size = sizeof(A) / sizeof(A[0]);
    printf("The size of the array is %d\n", size);
}

int main() {
//    int n;
//    int i;
//
//    printf("Enter the size: ");
//    scanf("%d", &n);
//
//    int *B = (int*)malloc(n * sizeof(int));
//
//    
//    for (i = 0; i < n; i++) {
//        B[i] = i + 1; 
//    }
//
//    
//    printf("Original array elements: ");
//    for (i = 0; i < n; i++) {
//        printf("%d ", B[i]);
//    }
//
//    
//    printf("\nEnter the new size: ");
//    scanf("%d", &n);
//
//    B = (int*)realloc(B, n * sizeof(int));
//
//    
//    for (i = 0; i < n; i++) {
//        B[i] = i + 1; 
//    }
//
//    
//    printf("Resized array elements: ");
//    for (i = 0; i < n; i++) {
//        printf("%d ", B[i]);
//    }
//
//    free(B); 
	
	
	int i, A[5]={1,2,3,4,5};
	int size = sizeof(A)/Sizeof(A[0]);
	printf("The size of arrray is %d ", size);
	add(A);
    return 0;
}


