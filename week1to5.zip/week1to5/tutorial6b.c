//Define the structure consisting of two floating point 
//members, called real and imaginary. Include the tag 
//complex within definition. Input the user input values 
//on both members and print them.

#include <stdio.h>

struct value{
	
	float real;
	float imaginary;
}complex;

int main(){
	
	printf("Enter real number");
	scanf("%2f", &complex.real);
	
	printf("Enter imaginary number");
	scanf("%2f", &complex.imaginary);
	
	printf("%f This is real number \nThis is imaginary %f", complex.real, complex.imaginary);
}