# include <stdio.h>

int main (){
	
	int x = 3;
	int y;
	int *px;
	
	px = &x; // store the value of x
	printf("\n  The value of x is : %d", x); //value of x
	printf("\n  The value of x is : %d", px); //address of x
	printf("\n  The value of x is : %d", &x); //address of x
	printf("\n  The value of x is : %d", px); //value of x *px -> derencing
	*px = 5;
	printf("\n The value of x is : %d", x); // see the change in x while changing value of *px
	return 0;
	
	
	
}