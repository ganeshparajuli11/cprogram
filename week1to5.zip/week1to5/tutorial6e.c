// Write a program implementing the concept of 
// nested structure.

#include <stdio.h>
#include <string.h>


struct Info {
    char name[50];
    int contact;
    char address[50];
};


struct College {
    char collegeName[60];
    char address[60];
    struct Info information;
};

int main() {
    struct College college1 = {
        .collegeName = "Salman Khan College",
        .address = "Kathmandu, Nepal",
        .information = {
            .name = "Ramesh Chaurasiya",
            .contact = 9843047262,
            .address = "Kapan"
        }
    };


    printf("College Name: %s\n", college1.collegeName);
    printf("College Address: %s\n", college1.address);
    printf("Person Name: %s\n", college1.information.name);
    printf("Contact: %d\n", college1.information.contact);
    printf("Person Address: %s\n", college1.information.address);

    return 0;
}
