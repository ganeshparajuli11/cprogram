// Write a program in C to check Armstrong and perfect numbers using the function.

# include <stdio.h>


int isArmstrongNumber(int number){
	
	int OrginalValue, remainder , sum=0;
	
	OrginalValue = number;
	
	while (number>0){
		
		remainder = number %10;
		
		sum = sum + (remainder*remainder*remainder);
		
		number = number/10;
	}
	
	
	
	return OrginalValue == sum;
}

int isPerfectNumber(int number){
	
	int remainder, sum =0;
	
	for(int i; i<number; i++){
		
		if (remainder == 0){
			
			sum = sum + i;
		}
	}
	
	return number == sum;
	
}

int main(){
	int a;
	printf("Enter a number");
	scanf("%d",&a);
	
	if (isArmstrongNumber(a)){
		
		printf("This is a Armstrong Number %d",a);
		
	} else{
		
		printf("This %d number is not a Armstrong number ",a);
	}
	
	if (isPerfectNumber){
		
		printf("\nThis is a Perfect Number %d",a);
	} else{
		
		printf("\nThis number is not a perfect number %d",a);
	}

	return 0;
}