#include <stdio.h>

int maxSize = 100;
int main() {
    FILE *file;
	
	int x[maxSize], y[maxSize];
    int count = 0;

    // Open the file in read mode
    file = fopen("datasetLR1.txt", "r");
    
    if (file == NULL) {
         printf("Error opening file");
        return 1;
    }

    // Read two integers separated by a comma from the file
    while(fscanf(file, "%d,%d", &x[count], &y[count]) == 2){
    	count ++;
	}
	
    fclose(file);
//	
////	printf("Reading values from files");
////	
////	for(int i=0; i<count; i++){
////		
////		printf("(%d, %d)\n",x[i],y[i]);
////	}
//	
//	// using linear regression (y=bx+a) before that lets find b and a
	
	int sumofY =0;
	for(int i=0; i<count; i++){
		
		sumofY = sumofY+ y[i];
	}
	
	printf("sum of element in y is: %d\n",sumofY);
	
	// sum of square of values of x  and sum of element of x 
	
	int sumofX = 0;
	long sqofX=0;
	
	for(int i=0; i<count; i++){
		
		sumofX = sumofX+ x[i];
	}
	
	printf("Sum of element in x: \n",sumofX);
	
	sqofX = sumofX * sumofX;
	printf("Square of x: %ld\n",sqofX);
	
	//product of x*y
	
	long productofXY;
	
	for(int i=0; i<count; i++){
		
		productofXY = productofXY + (x[i]*y[i]);
	}
	
	printf("Sum of product of xy %ld\n",productofXY);
	
	// total no of count
	int n = count;
	printf("Total no of cordinates : %d\n",n);
	
	// sum of square of each element of x
	int sumofsqofEachelementX = 0;
	for(int i=0; i<count; i++){
		
		sumofsqofEachelementX = sumofsqofEachelementX+ (x[i]* x[i]);
	}
	
	printf("Sum of square of each element of x",sumofsqofEachelementX);
	
	// final calculation for value of a
	
	float a = ((sumofY)* (sumofsqofEachelementX) - (sumofX)*(productofXY))/ n*(sumofsqofEachelementX)-(sqofX);
	printf("Value of a is : %.2f\n",a);
	
	// calculating value of b
	
	float b = (n*(productofXY) - (sumofX)*(sumofY))/ (n*(sumofsqofEachelementX)) - sqofX;
	printf("Value of b is : %.2f\n",b);
	
	//making final equation 
	
	float yTarget,xValue;
	
	printf("Enter the value of X");
	scanf("%f",&xValue);
	
	yTarget = b*xValue + a;
	
	printf("The value of Y value is : %.2f", yTarget);
	
    return 0;
}