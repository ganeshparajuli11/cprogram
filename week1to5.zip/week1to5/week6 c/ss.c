#include <stdio.h>
#include <string.h>
void main(){
char name1[10]="ram";
char name2;
printf("String copy result:%s",strcpy(name1,name2));
}