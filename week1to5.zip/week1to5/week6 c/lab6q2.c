//Write a program to read information from the above file
//employee.txt

#include <stdio.h>

int main() {
    FILE *fp;
    fp = fopen("employee.txt", "r");

    if (fp == NULL) {
        printf("Error opening file");
        return 1;
    }

    char ch[100];

    int index = 0;
    int c;

    while ((c = fgetc(fp)) != EOF && index < 99) {
    	
        ch[index] = (char)c;
        index++;
    }

    ch[index] = '\0';

    printf("%s", ch);

    fclose(fp);

    return 0;
}
