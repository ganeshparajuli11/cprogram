//Write a c program to read integers from the user 
//and append the sum to the end in the file
//name sum.txt

#include <stdio.h>

int main(){
	FILE *fp;
	
	fp = fopen("sum.txt","a");
	
	if(fp == NULL){
		
		printf("Null value");
		
		return 0;
	}
	
	int a , b;
	int sum =0;
	
	printf("Enter two number");
	scanf("%d %d",&a,&b);
	sum = a+b;
	
	fprintf(fp,"Sum of numbers: %d",sum); 
	
	printf("Append successful");
	
	return 0;
	
}