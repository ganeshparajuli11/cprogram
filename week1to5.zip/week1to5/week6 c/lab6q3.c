//WAP to add new employee details in employee.txt file.

#include <stdio.h>

struct employee{
	
	char name[50];
	int age;
	int salary;
	
};

int main(){
	
	FILE *fp;
	
	fp = fopen("employee.txt","w");
	
	if(fp==NULL){
		
		printf("file have null value");
		
		return 1;
	}
	
	struct employee employ[3];
	
	for(int i=0; i<3; i++){
		
		printf("Enter name ");
		scanf("%s",employ[i].name);
		
		printf("Enter age ");
		scanf("%d",&employ[i].age);
		
		printf("Enter your salary ");
		scanf("%d",&employ[i].salary);
	}
	
	for(int i=0; i<3; i++){
		
		fprintf(fp,"Name : %s\nAge : %d\nSalary : %d\n", employ[i].name, employ[i].age, employ[i].salary);
		printf("\n");
		
	}
	
	printf("\n");
	
	for(int i =0; i<3; i++){
		
		printf("Name : %s\nAge : %d\nSalary : %d\n", employ[i].name, employ[i].age, employ[i].salary);
		printf("\n");
		
	}
	
	fclose(fp);
	
	return 0;
	
}
