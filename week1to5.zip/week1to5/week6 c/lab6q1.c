//Create a structure named employee having members: empName, age 
//and salary. Use this structure to read the name, age and salary 
//of 3 employees and write entered information to a
//file employee.txt D:\ drive

#include <stdio.h>

struct employee{
	
	char empName[40];
	int age;
	int salary;
	
};

int main(){
	
	FILE *fp;	
	fp = fopen("employee.txt","w");
	
	if(fp==NULL){
		
		printf("Error opening file");
		
		return 1;
	}
	struct employee employ[3];
	
	for(int i =0; i<3; i++){
		
		printf("Enter employee name ");
		scanf("%s", employ[i].empName);
		
		printf("Enter employee age ");
		scanf("%d", &employ[i].age);
		
		printf("Enter employee salary ");
		scanf("%d", &employ[i].salary); 
	}
		
	
	
	// printing data in file
	for (int i =0; i<3; i++){
		
		fprintf(fp, " Name : %s\n age: %d\n Salary: %d\n", employ[i].empName,employ[i].age,employ[i].salary);
		printf("\n");
	}
	
	// printing in console
	printf("\n");
	for(int i=0; i<3; i++){
		
		printf (" Name : %s\n age: %d\n Salary: %d\n", employ[i].empName,employ[i].age,employ[i].salary);
		printf("\n");
	}
	
	fclose(fp);
	
	return 0;
	
}