//Write a program to copy content from odd.txt and event.txt 
//file to a new file numbers.txt file.

#include <stdio.h>

int main() {
    FILE *fp1, *fp2, *fp3;

    fp1 = fopen("odd.txt", "r");
    fp2 = fopen("even.txt", "r");
    fp3 = fopen("numbers.txt", "w");

    if (fp1 == NULL || fp2 == NULL || fp3 == NULL) {
        printf("Error opening files");
        return 1;
    }

    int ch;

    
    while ((ch = fgetc(fp1)) != EOF) {
        fputc(ch, fp3);
    }

   
    while ((ch = fgetc(fp2)) != EOF) {
        fputc(ch, fp3);
    }

    printf("Contents copied successfully.");

    fclose(fp1);
    fclose(fp2);
    fclose(fp3);

    return 0;
}
