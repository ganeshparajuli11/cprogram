// Write a program in C to read integers from the user 
//until the user says "no". After reading the
//data write all the odd numbers to a file named odd.txt 
//and all the even numbers to file even.txt

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() {
    FILE *fp1;
    FILE *fp2;

    fp1 = fopen("odd.txt", "w");
    fp2 = fopen("even.txt", "w");

    char c[3];
    int num[100];
    int size = sizeof(num) / sizeof(num[0]);

    int even[100];
    int odd[100];

    int i = 0;  // Initialize loop counter

    while (strcmp(c, "no") != 0) {
        printf("Enter a number or type 'no' to end: ");
        scanf("%s", c);

        if (strcmp(c, "no") == 0) {
            break;
        }

        num[i] = atoi(c);

        if (num[i] % 2 == 0) {
            even[i] = num[i];
            fprintf(fp2, "Even number: %d\n", even[i]);
        } else {
            odd[i] = num[i];
            fprintf(fp1, "Odd number: %d\n", odd[i]);
        }

        i++;
    }

    fclose(fp1);
    fclose(fp2);

    return 0;
}
