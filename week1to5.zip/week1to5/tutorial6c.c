//Define structure and store information of 3 students
//and display it using structure. (Use array of structure)

# include<stdio.h>
# include <string.h>
struct information{
	
	char name[50] ;
	int rollno;
	char section;
}student[3];

int main(){
	
	
	for (int i=0; i<3; i++){
		
		printf("Enter student name");
		scanf("%s",student[i].name);
		
		printf("Enter student rollno");
		scanf("%d",&student[i].rollno);		

		printf("Enter student section");
		scanf("%s",&student[i].section);

	
	}
	
    for (int i = 0; i < 3; i++) {
        printf("Information of student %d:\n", i + 1);
        printf("Name: %s\n", student[i].name);
        printf("Roll No: %d\n", student[i].rollno);
        printf("Section: %s\n", student[i].section);
        printf("\n");
    }
    
    return 0;
}

