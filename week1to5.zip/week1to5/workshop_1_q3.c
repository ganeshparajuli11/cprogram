// 3.	Write a program to print out all triangular numbers from 1 up to nth term.

# include <stdio.h>

int main (){
	
	int num, trang;
	printf("Enter a number ");
	scanf("%d",&num);
	
	for(int i=1; i<=num; i++ ){
		
		trang = (i*(i +1))/2;
		printf("%d ", trang);
	}
	
	
	return 0;
	
} 