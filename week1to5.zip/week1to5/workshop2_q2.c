// Write a function that takes two integers as arguments and return the greatest among them.

# include <stdio.h>
int num(int x1, int x2){
	
	int greater = 0;
	if (x1>x2){
		
		greater = x1;
	} else if (x2>x1){
		
		greater = x2;
	} else{
		
		greater = x1;
	}
	
	return greater;
	
}

int main(){
	
	int x,y;
	printf("Enter two number");
	scanf("%d %d",&x,&y);
	
	int ans = num(x,y);
	
	printf("greater num is %ans",ans);