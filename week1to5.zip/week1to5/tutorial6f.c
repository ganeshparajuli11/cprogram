#include <stdio.h>

struct Point {
    int x;
    int y;
};


struct Point createPoint(int x, int y) {
    struct Point newPoint;
    newPoint.x = x;
    newPoint.y = y;
    return newPoint;
}

int main() {
    struct Point myPoint = createPoint(3, 4);
    printf("Coordinates of the Point: (%d, %d)\n", myPoint.x, myPoint.y);

    return 0;
}
