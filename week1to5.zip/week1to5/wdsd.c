#include <stdio.h>
#include <stdlib.h>

int main(){
	
	int n, i, *ptr;
	
	printf("Enter the number you want to store");
	scanf("%d",&n);
	ptr = /* Type casting*/(int *)malloc(n*sizeof(int));
	
	for(i=0; i<n; i++){
		
		scanf("\n%d",(ptr+i));
	}
	
	printf("\nEntered values are");
	for(i=0; i<n; i++){
		
		printf("\n%d  ",*(ptr+i));
	}
	
		if(ptr == NULL){
		
		printf("\nMemory allocation failed !!");
	} else{
		
		printf("\nMemory allocation successful ");
	}
	
	free(ptr);
	
	
	return 0;
}