//Write a structure to store the names, salary and hours of 
//work per day of 5 employees in a company. Write a program 
//to increase the salary depending on the number of hours of 
//work per day as follows and then print the name of all the
//employees along with their final salaries.
//
//Hours of work per day 8 10 >=12
//Increase in salary $50 $100 $150

# include <stdio.h>

struct Employees {
    char name[60];
    int salary;
    int hourofWork;
};

int main() {
    struct Employees employ[5];

    for (int i = 0; i < 5; i++) {
        printf("Enter full name of %d employee: ", i + 1);
        scanf("%s", employ[i].name);

        printf("Enter no of hours worked: ");
        scanf("%d", &employ[i].hourofWork);

        
        if (employ[i].hourofWork < 8) {
            employ[i].salary = 50 * employ[i].hourofWork;
        } else if (employ[i].hourofWork < 10) {
            employ[i].salary = 100 * employ[i].hourofWork;
        } else if (employ[i].hourofWork >= 12) {
            employ[i].salary = 150 * employ[i].hourofWork;
        }
    }

    printf("\nPrinting people with their salary\n");

    for (int i = 0; i < 5; i++) {
        printf("Name: %s\n", employ[i].name);
        printf("Salary: %d\n", employ[i].salary);
        printf("\n");
    }

    return 0;
}
