//Write a C program to take an array using dynamic memory allocation
//and print them, later add elements onto that array using the realloc
//function and print them all.


#include <stdio.h>
#include <stdlib.h>

int main() {
    int value1, *arr1;
    printf("Enter the total number of values to store in the first array: ");
    scanf("%d", &value1);

int size = sizeof(Arr)/sizeof(arr[0]);
    // Allocate memory for the first array
    arr1 = (int *)malloc(value1 * sizeof(int));

    // Check if memory allocation is successful
    if (arr1 == NULL) {
        printf("Memory allocation is failed\n");
        return 1;
    }

    // Input values for the first array
    for (int i = 0; i < value1; i++) {
        printf("Enter the %d element to store in array: ", i + 1);
        scanf("%d", &arr1[i]);
    }

    // Print the values of the first array
    printf("Values in the first array: ");
    for (int i = 0; i < value1; i++) {
        printf("%d ", arr1[i]);
    }

    // Use realloc to double the size of the array
    int *temp = (int *)realloc(arr1, 2 * value1 * sizeof(int));

    // Check if realloc is successful
    if (temp != NULL) {
        arr1 = temp;

        // Input more values for the expanded array
        for (int i = value1; i < 2 * value1; i++) {
            printf("\nEnter the %d element to store in the array: ", i + 1);
            scanf("%d", &arr1[i]);
        }

        // Print all values in the updated array
        printf("\nValues in the updated array: ");
        for (int i = 0; i < 2 * value1; i++) {
            printf("%d ", arr1[i]);
        }
    } else {
        printf("Memory reallocation failed. Exiting...\n");
    }

    // Free dynamically allocated memory
    free(arr1);

    return 0;
}
