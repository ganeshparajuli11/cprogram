// Write a program to sort an array elements in ascending order.

#include <stdio.h>

void sorting(int arr[], int size) {
    for (int i = 0; i < size - 1; i++) {
        int flag = 0;
        for (int j = 0; j < size - 1 - i; j++) { 

            if (arr[j] > arr[j + 1]) {
                int temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
                flag = 1;
            }
        }
        
        if (flag == 0) {
            break;
        }
    }
}

int main() {
    int arr[] = {5, 7, 8, 9, 10};
    int size = sizeof(arr) / sizeof(arr[0]);
    sorting(arr, size);

    printf("Sorted Array: ");
    for (int i = 0; i < size; i++) {
        printf("%d ", arr[i]);
    }

    return 0;
}
