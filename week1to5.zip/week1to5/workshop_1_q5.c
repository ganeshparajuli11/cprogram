// 5.	Make changes in the program of Question Number 4. Ask characters from 
    //the user until an enter key is pressed.
     //Hint: The ASCII Value of Enter key is 13.
# include <stdio.h>
# include <conio.h>


int main (){
	
	char ch;
	printf("Enter a character: ");
	ch = getche();
	
	while (ch != 13){
		if (ch>='A' && ch<= 'Z'){
			ch= ch+32;
		}
		
		printf("\n %c",ch);
		printf("\n Enter the character again: ");
		ch = getche();
	}
	
	return 0;	
}
