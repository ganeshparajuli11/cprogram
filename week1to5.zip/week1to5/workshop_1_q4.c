//4.	Write a program to input a character from the user and print it in lowercase. If the character is in uppercase then you have 
//to change it in lowercase and if it is in lowercase then you have to print as it is.

# include <stdio.h>

int main () {
	
	char c;
	
	printf("Enter a character A-Z: ");
	scanf("%c",&c);
	// A is 65 and Z is 97
	// a is 97 and z is 122
	
	if (c > 96 && c<123){
		printf("The lower case is:  %c",c);
	}
	
	else if (c > 64 && c < 91){
		
		printf(" This word in lowercase is %c",c+32);
	}
	
	else{
		printf("Enter a character A-Z");
		scanf("m%c",&c);
	}
	
	return 0;
}