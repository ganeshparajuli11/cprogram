// WAP to write a program to show different function 
//of string like strlen, strcat, strcpy, strcmp.

# include <stdio.h>
# include <string.h>

int main(){
	
	char Name [] = {"Ganesh"};
	char lName [] = {"Parajuli"};
	char store[20];
	
	int firstNamelength = strlen(Name);
	int lastNamelength = strlen(lName);
	
	printf("Length of first name : %d\n", firstNamelength);
	printf("Length of first name : %d\n", lastNamelength);
	
	strcat(Name, " ");
	strcat(Name, lName);
	
	printf("Full name: ", Name);
	
	strcpy(store, Name);
	printf("Copied string", store);
	
	
	int result = (Name, lName);
	if (result==0){
		
		printf("The strings are equal. \n");
	} else if (result <0){
		
		printf("Name is less than lastName. \n");
	} else{
		
		printf("Name is greater than lastName \n");
	}
	
	
	return 0;
}