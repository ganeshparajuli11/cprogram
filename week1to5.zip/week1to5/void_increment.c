# include <stdio.h>

void increment (int *ptr1){
	
	*ptr1 = *ptr1 +1;
	
}

int main(){
	
	int x = 10;
	printf("\n The value before function call is %d",x);
	increment (&x);
	printf("\n The value before function call is %d",x);
	
}