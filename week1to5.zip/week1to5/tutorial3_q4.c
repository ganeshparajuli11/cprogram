// WAP to read 10 numbers from keyboard to
// store these num into array and then
// calculate sum of these num using function

#include <stdio.h>
int calculateSum(int array[], int size){
	
	int sum =0;
	for (int i =0; i<size; ++i){
		
		sum = sum + array[i];
	}
	
	return sum;
}

int main(){
	
	const int size =10;
	int Array[size];
	
	printf("Enter 10 numbers");	
	for(int i = 0; i < size; i++){
			
		printf("Enter number %d: ", i+1);
		scanf("%d", &Array[i]);
		
	}
		
	int sum = calculateSum(Array,size);	
	
	printf("Sum of the numbers: %d\n", sum);
}