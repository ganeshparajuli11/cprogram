// Write a program to check whether two given 
// strings are an anagram.

#include <stdio.h>
#include <string.h>

int main() {
    char str1[10] = "Silent";
    char str2[10] = "listen";

    int sizea = strlen(str1);
    int sizeb = strlen(str2);

    int counta = 0;
    int countb = 0;
    int finalcount = 0;

    if (sizea == sizeb) {
        for (int i = 0; i < sizea; i++) {
            counta = 0; 

            for (int j = 0; j < sizea; j++) {
                if (str1[i] == str1[j]) {
                    counta = counta + 1;
                }
            }

            countb = 0; 

            for (int j = 0; j < sizeb; j++) {
                if (str1[i] == str2[j]) {
                    countb = countb + 1;
                }
            }

            if (counta == countb && counta >= 1) {
                finalcount = 1;
            }
        }
    }
 
    if (finalcount == 1) {
        printf("The strings are anagrams.\n");
    } else {
        printf("The strings are not anagrams.\n");
    }

    return 0;
}


